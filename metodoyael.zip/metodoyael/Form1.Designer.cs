﻿namespace ProyMetodosNumericos2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.raicesDeEcuacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metodoDeBiseccionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iteracionDePuntoFijoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metodoDeLaSecanteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metodoDeMullerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metodoDeNewtonRaphsonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raicesDeUnPolinomioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.raicesDeEcuacionesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // raicesDeEcuacionesToolStripMenuItem
            // 
            this.raicesDeEcuacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.metodoDeBiseccionToolStripMenuItem,
            this.iteracionDePuntoFijoToolStripMenuItem,
            this.metodoDeLaSecanteToolStripMenuItem,
            this.metodoDeMullerToolStripMenuItem,
            this.metodoDeNewtonRaphsonToolStripMenuItem,
            this.raicesDeUnPolinomioToolStripMenuItem});
            this.raicesDeEcuacionesToolStripMenuItem.Name = "raicesDeEcuacionesToolStripMenuItem";
            this.raicesDeEcuacionesToolStripMenuItem.Size = new System.Drawing.Size(130, 20);
            this.raicesDeEcuacionesToolStripMenuItem.Text = "Raices de ecuaciones";
            this.raicesDeEcuacionesToolStripMenuItem.Click += new System.EventHandler(this.raicesDeEcuacionesToolStripMenuItem_Click);
            // 
            // metodoDeBiseccionToolStripMenuItem
            // 
            this.metodoDeBiseccionToolStripMenuItem.Name = "metodoDeBiseccionToolStripMenuItem";
            this.metodoDeBiseccionToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.metodoDeBiseccionToolStripMenuItem.Text = "Metodo de Biseccion";
            this.metodoDeBiseccionToolStripMenuItem.Click += new System.EventHandler(this.metodoDeBiseccionToolStripMenuItem_Click);
            // 
            // iteracionDePuntoFijoToolStripMenuItem
            // 
            this.iteracionDePuntoFijoToolStripMenuItem.Name = "iteracionDePuntoFijoToolStripMenuItem";
            this.iteracionDePuntoFijoToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.iteracionDePuntoFijoToolStripMenuItem.Text = "Iteracion de Punto Fijo";
            // 
            // metodoDeLaSecanteToolStripMenuItem
            // 
            this.metodoDeLaSecanteToolStripMenuItem.Name = "metodoDeLaSecanteToolStripMenuItem";
            this.metodoDeLaSecanteToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.metodoDeLaSecanteToolStripMenuItem.Text = "Metodo de la Secante";
            // 
            // metodoDeMullerToolStripMenuItem
            // 
            this.metodoDeMullerToolStripMenuItem.Name = "metodoDeMullerToolStripMenuItem";
            this.metodoDeMullerToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.metodoDeMullerToolStripMenuItem.Text = "Metodo de Muller";
            // 
            // metodoDeNewtonRaphsonToolStripMenuItem
            // 
            this.metodoDeNewtonRaphsonToolStripMenuItem.Name = "metodoDeNewtonRaphsonToolStripMenuItem";
            this.metodoDeNewtonRaphsonToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.metodoDeNewtonRaphsonToolStripMenuItem.Text = "Metodo de Newton Raphson";
            // 
            // raicesDeUnPolinomioToolStripMenuItem
            // 
            this.raicesDeUnPolinomioToolStripMenuItem.Name = "raicesDeUnPolinomioToolStripMenuItem";
            this.raicesDeUnPolinomioToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.raicesDeUnPolinomioToolStripMenuItem.Text = "Raices de un polinomio";
            this.raicesDeUnPolinomioToolStripMenuItem.Click += new System.EventHandler(this.raicesDeUnPolinomioToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 367);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Menu Principal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem raicesDeEcuacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem metodoDeBiseccionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iteracionDePuntoFijoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem metodoDeLaSecanteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem metodoDeMullerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem metodoDeNewtonRaphsonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raicesDeUnPolinomioToolStripMenuItem;
    }
}

