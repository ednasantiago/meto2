﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyMetodosNumericos2
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void raicesDeEcuacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMetododeBiseccion ventanaBiseccion = new frmMetododeBiseccion();
            ventanaBiseccion.Show();
        }

        private void metodoDeBiseccionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void raicesDeUnPolinomioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
