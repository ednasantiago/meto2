﻿namespace ProyMetodosNumericos2
{
    partial class FrmMetododeMuller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_P0R = new System.Windows.Forms.TextBox();
            this.txt_P1R = new System.Windows.Forms.TextBox();
            this.txt_P2R = new System.Windows.Forms.TextBox();
            this.txt_P0IM = new System.Windows.Forms.TextBox();
            this.txt_P1IM = new System.Windows.Forms.TextBox();
            this.txt_P2IM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_ErrorMaximo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_NumMaxIter = new System.Windows.Forms.TextBox();
            this.btn_CalcularRaiz = new System.Windows.Forms.Button();
            this.dgvTablaMetodoMuller = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTablaMetodoMuller)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Bargain_Demo", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(280, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Metodo de Muller";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(115, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "REAL ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(207, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "IMAGINARIO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(53, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "P0:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(53, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "P1:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "P2:";
            // 
            // txt_P0R
            // 
            this.txt_P0R.Location = new System.Drawing.Point(101, 146);
            this.txt_P0R.Name = "txt_P0R";
            this.txt_P0R.Size = new System.Drawing.Size(84, 20);
            this.txt_P0R.TabIndex = 6;
            // 
            // txt_P1R
            // 
            this.txt_P1R.Location = new System.Drawing.Point(101, 194);
            this.txt_P1R.Name = "txt_P1R";
            this.txt_P1R.Size = new System.Drawing.Size(84, 20);
            this.txt_P1R.TabIndex = 7;
            // 
            // txt_P2R
            // 
            this.txt_P2R.Location = new System.Drawing.Point(101, 246);
            this.txt_P2R.Name = "txt_P2R";
            this.txt_P2R.Size = new System.Drawing.Size(84, 20);
            this.txt_P2R.TabIndex = 8;
            // 
            // txt_P0IM
            // 
            this.txt_P0IM.Location = new System.Drawing.Point(224, 146);
            this.txt_P0IM.Name = "txt_P0IM";
            this.txt_P0IM.Size = new System.Drawing.Size(84, 20);
            this.txt_P0IM.TabIndex = 9;
            // 
            // txt_P1IM
            // 
            this.txt_P1IM.Location = new System.Drawing.Point(224, 194);
            this.txt_P1IM.Name = "txt_P1IM";
            this.txt_P1IM.Size = new System.Drawing.Size(84, 20);
            this.txt_P1IM.TabIndex = 10;
            // 
            // txt_P2IM
            // 
            this.txt_P2IM.Location = new System.Drawing.Point(224, 246);
            this.txt_P2IM.Name = "txt_P2IM";
            this.txt_P2IM.Size = new System.Drawing.Size(84, 20);
            this.txt_P2IM.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(359, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 23);
            this.label7.TabIndex = 12;
            this.label7.Text = "ERROR MAXIMO";
            // 
            // txt_ErrorMaximo
            // 
            this.txt_ErrorMaximo.Location = new System.Drawing.Point(543, 129);
            this.txt_ErrorMaximo.Name = "txt_ErrorMaximo";
            this.txt_ErrorMaximo.Size = new System.Drawing.Size(84, 20);
            this.txt_ErrorMaximo.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(373, 189);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 23);
            this.label8.TabIndex = 14;
            this.label8.Text = "NUM.MAX.ITER";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txt_NumMaxIter
            // 
            this.txt_NumMaxIter.Location = new System.Drawing.Point(543, 192);
            this.txt_NumMaxIter.Name = "txt_NumMaxIter";
            this.txt_NumMaxIter.Size = new System.Drawing.Size(84, 20);
            this.txt_NumMaxIter.TabIndex = 15;
            // 
            // btn_CalcularRaiz
            // 
            this.btn_CalcularRaiz.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_CalcularRaiz.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CalcularRaiz.Location = new System.Drawing.Point(458, 238);
            this.btn_CalcularRaiz.Name = "btn_CalcularRaiz";
            this.btn_CalcularRaiz.Size = new System.Drawing.Size(111, 35);
            this.btn_CalcularRaiz.TabIndex = 16;
            this.btn_CalcularRaiz.Text = "CALCULAR RAIZ";
            this.btn_CalcularRaiz.UseVisualStyleBackColor = false;
            // 
            // dgvTablaMetodoMuller
            // 
            this.dgvTablaMetodoMuller.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTablaMetodoMuller.Location = new System.Drawing.Point(58, 295);
            this.dgvTablaMetodoMuller.Name = "dgvTablaMetodoMuller";
            this.dgvTablaMetodoMuller.Size = new System.Drawing.Size(704, 197);
            this.dgvTablaMetodoMuller.TabIndex = 17;
            // 
            // FrmMetododeMuller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 509);
            this.Controls.Add(this.dgvTablaMetodoMuller);
            this.Controls.Add(this.btn_CalcularRaiz);
            this.Controls.Add(this.txt_NumMaxIter);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_ErrorMaximo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_P2IM);
            this.Controls.Add(this.txt_P1IM);
            this.Controls.Add(this.txt_P0IM);
            this.Controls.Add(this.txt_P2R);
            this.Controls.Add(this.txt_P1R);
            this.Controls.Add(this.txt_P0R);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrmMetododeMuller";
            this.Text = "FrmMetododeMuller";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTablaMetodoMuller)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_P0R;
        private System.Windows.Forms.TextBox txt_P1R;
        private System.Windows.Forms.TextBox txt_P2R;
        private System.Windows.Forms.TextBox txt_P0IM;
        private System.Windows.Forms.TextBox txt_P1IM;
        private System.Windows.Forms.TextBox txt_P2IM;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_ErrorMaximo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_NumMaxIter;
        private System.Windows.Forms.Button btn_CalcularRaiz;
        private System.Windows.Forms.DataGridView dgvTablaMetodoMuller;
    }
}