﻿using System;
using System.Windows.Forms;

namespace ProyMetodosNumericos2
{
    public partial class frmMetododeBiseccion : Form
    {
        public frmMetododeBiseccion()
        {
            InitializeComponent();
        }

        private void frmMetododeBiseccion_Load(object sender, EventArgs e)
        {
            try
            {
                // Configurar las columnas del DataGridView
                dgvTablaBiseccion.Columns.Add("Iteracion", "Número de Iteración");
                dgvTablaBiseccion.Columns.Add("a", "a");
                dgvTablaBiseccion.Columns.Add("b", "b");
                dgvTablaBiseccion.Columns.Add("c", "c");
                dgvTablaBiseccion.Columns.Add("f(a)", "F(a)");
                dgvTablaBiseccion.Columns.Add("f(c)", "F(c)");
                dgvTablaBiseccion.Columns.Add("Error", "Error");

                // Asignar evento al botón
                btnCalcular.Click += new EventHandler(btnCalcular_Click);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al inicializar el formulario: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private double Funcion(double x)
        {
            return Math.Pow(x, 3) - x - 1;  // Ejemplo: f(x) = x³ - x - 1
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Capturar los valores desde los TextBox
                double a = double.Parse(txt_a.Text);
                double b = double.Parse(txt_b.Text);
                double errorMax = double.Parse(txtErrorMax.Text);
                int numMaxIter = int.Parse(txtNumMaxIter.Text);

                // Limpiar DataGridView antes de iniciar
                dgvTablaBiseccion.Rows.Clear();

                // Aplicar el método de Bisección
                MetodoBiseccion(a, b, errorMax, numMaxIter);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Entrada no válida", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MetodoBiseccion(double a, double b, double errorMax, int numMaxIter)
        {
            if (Funcion(a) * Funcion(b) >= 0)
            {
                MessageBox.Show("El intervalo no contiene una raíz válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int iteracion = 0;
            double c = 0, error = 0;

            while (iteracion < numMaxIter)
            {
                double c_anterior = c;
                c = (a + b) / 2;  // Punto medio

                double f_a = Funcion(a);
                double f_c = Funcion(c);

                if (iteracion > 0)
                {
                    error = Math.Abs((c - c_anterior) / c);  // Error relativo
                }

                // Agregar fila al DataGridView
                dgvTablaBiseccion.Rows.Add(iteracion + 1, a, b, c, f_a, f_c, error);

                if (Math.Abs(f_c) < errorMax || error < errorMax)
                {
                    MessageBox.Show("Raíz encontrada: " + c, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (f_a * f_c < 0)
                {
                    b = c;
                }
                else
                {
                    a = c;
                }

                iteracion++;
            }

            MessageBox.Show("No se encontró una raíz con la precisión deseada.", "Finalización", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
